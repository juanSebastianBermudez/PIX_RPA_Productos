/*========================================================
  TABLA: Productos
  DESCRIPCI�N: Almacena informaci�n de Productos 
  POR: Juan Sebastian Bermudez
  EMPRESA: PIX RPA
=========================================================*/

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'PIX_PRA')
BEGIN
CREATE DATABASE PIX_PRA
END



USE [PIX_PRA]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.Productos', 'U') IS NULL
    CREATE TABLE [dbo].[Productos](
	    [id] [int] NOT NULL,
	    [title] NVARCHAR(500) NULL,
	    [price] REAL NULL,
	    [category] NVARCHAR(500) NULL,
	    [description] NVARCHAR(MAX) NULL,
	    [fecha_insercion] [datetime2](0) NULL,
         CONSTRAINT [PK_Productos] PRIMARY KEY CLUSTERED 
        (
	        [id] ASC
        )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
        ) ON [PRIMARY]
        GO

        ALTER TABLE [dbo].[Productos] ADD  CONSTRAINT [DF_Productos_FechaInsercion]  DEFAULT (sysdatetime()) FOR [fecha_insercion]
    GO
GO